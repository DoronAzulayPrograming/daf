<?php
/** @var DafCore\IComponent $this  */
echo $this->RenderChildContent();