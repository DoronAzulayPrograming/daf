<?php 
/** @var DafCore\IComponent $this */
/** @var string $msg */

$msg = $this->Parameter("Msg");
?>

<Alert Msg="<?=$msg ?>" /> 