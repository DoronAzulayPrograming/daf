<?php
/** @var DafCore\IComponent $this */
$this->Use([
    'App\Views\Components\*',
    'App\Views\Components\NavTabs\*',
    'App\Views\Components\Auth\*',
]);

//'App\Views\Components\NavTabs\*',
