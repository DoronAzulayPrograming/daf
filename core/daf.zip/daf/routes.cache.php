<?php
return unserialize('a:2:{s:6:"routes";a:1:{s:3:"get";a:2:{s:1:"/";a:1:{i:0;s:10:"Pages/Home";}s:11:"/GetStarted";a:1:{i:0;s:16:"Pages/GetStarted";}}}s:4:"meta";a:0:{}}');
